# HITU_Simulator
A high-intensity therapeutic ultrasound simulation package written for matlab.  It performs ultrasound propagation of axisymmetric beams as well as heating and calculation of thermal dose in tissue. This is an update of the HIFU_Simulator package.
